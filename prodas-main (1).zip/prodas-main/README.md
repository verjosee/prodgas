Kelas X-RPL BL
